function igi() {
    let wpara = document.querySelector("#ara");
    wpara.innerHTML = `
       <div class="container" id="damo">

      <div class="row d.flex">
      <div class = "col">
      <img class="rounded  mt-3" src="./images2/295.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/295.mp3"  type="">
       </audio>
           <p class="paras">295 by Sidhu Moose wala</p>
     </div>
      </div>
      <hr>
  
      <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images2/Bebe.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/babu.mp3"  type="">
       </audio>
           <p class="paras">Bepe Babu by Harsh Likhari</p>
     </div>
      </div>
      <hr>
       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images2/Gunday.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/navneet.mp3"  type="">
       </audio>
           <p class="paras">Gunday by Navneet</p>
     </div>
      </div>
      <hr>

       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images2/Roots.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/root.mp3"  type="">
       </audio>
           <p class="paras">Root by Bintu Pabra</p>
     </div>
      </div>
      <hr>
      <div class="row d.flex">
          <div class = "col">
          <img class="rounded" src="./images2/YadavBrand.jpg" alt="" width=80px>
           </div>
           <div class="col me-5 mt-3">   
             <audio controls>
                <source src="./song2/yadav.mp3"  type="">
           </audio>
               <p class="paras">Yadav-Brand 2 by Sunny Yaduvanshi</p>
         </div>
          </div>
  
  
      </div>
      </div>
      `;
  //   wpara.classList.add("hello");
  //   let head = document.querySelector(".hello");
  //   head.style.display = "none";
  }
  


  function image() {
    let wpara = document.querySelector("#tara");
    wpara.innerHTML = `
        <div class="container" id="damo">

        <div class="row d.flex">
        <div class = "col">
        <img class="rounded  mt-3" src="./images3/kham.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song3/kah.mp3"  type="">
         </audio>
             <p class="paras">Khamoshiyan by Arijit Singh</p>
       </div>
        </div>
        <hr>
    
        <div class="row d.flex">
        <div class = "col">
        <img class="rounded" src="./images3/dard.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song3/hum.mp3"  type="">
         </audio>
             <p class="paras">Humdard by Arijit Singh</p>
       </div>
        </div>
        <hr>
         <div class="row d.flex">
        <div class = "col">
        <img class="rounded" src="./images3/Hamari.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song3/kah.mp3"  type="">
         </audio>
             <p class="paras">Hamari Adhuri Kahani by Arijit Singh</p>
       </div>
        </div>
        <hr>
        <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images/kahani.jpeg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/kahani.mp3"  type="">
       </audio>
           <p class="paras">Kahani Suno by Kaifi Khalil</p>
     </div>
      </div>
  
        <hr>
        <div class="row d.flex">
            <div class = "col">
            <img class="rounded" src="./images3/tum.jpg" alt="" width=80px>
             </div>
             <div class="col me-5 mt-3">   
               <audio controls>
                  <source src="./song3/agar.mp3"  type="">
             </audio>
                 <p class="paras">Agar tum sath ho by Alka </p>
           </div>
            </div>
    
    
        </div>
        </div>
      `;
  //   wpara.classList.add("hello");
  //   let head = document.querySelector(".hello");
  //   head.style.display = "none";
  }
  
  function fun5() {
    let wpara = document.querySelector("#p5");
    wpara.innerHTML = `
     <div class="container" id="damo">
       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./image4/Moh.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/navneet.mp3"  type="">
       </audio>
           <p class="paras">Mohtarma by Khala ala</p>
     </div>
      </div>
      <hr>

       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./image4/byaah.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/root.mp3"  type="">
       </audio>
           <p class="paras">Byaah by Khala ala</p>
     </div>
      </div>
      <hr>
      <div class="row d.flex">
          <div class = "col">
          <img class="rounded" src="./image4/bullet.webp" alt="" width=80px>
           </div>
           <div class="col me-5 mt-3">   
             <audio controls>
                <source src="./song2/yadav.mp3"  type="">
           </audio>
               <p class="paras">Bullet by Khasa ala</p>
         </div>
          </div>
  
  
      </div>
      </div>
      </div>
      `;
  //   wpara.classList.add("hello");
  //   let head = document.querySelector(".hello");
  //   head.style.display = "none";
  }
  