function imgi() {
    let newpara = document.querySelector("#para");
  
    // let para = document.querySelector("#para")
  
    // para.classList.add("hello")
  
    // let ahead = document.querySelector(".hello")
    // ahead.style.display = "block"
  
    newpara.innerHTML = `
      <div class="container hello" id="dynamo">
      <div class="row d.flex">
      <div class = "col">
      <img class="rounded  mt-3" src="./images/mahi.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/mahi.mp3"  type="">
       </audio>
           <p class="paras">O mahi O mahi by Arijit singh</p>
     </div>
      </div>
      <hr>
      
  
      <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images/malang.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/malang.mp3"  type="">
       </audio>
           <p class="paras">Malang Sajna by Sachet Tandon</p>
     </div>
      </div>
      <hr>
       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images/kahani.jpeg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/kahani.mp3"  type="">
       </audio>
           <p class="paras">Kahani Suno by Kaifi Khalil</p>
     </div>
      </div>
      <hr>
   
  
       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images/heeriye.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/heeriye.mp3"  type="">
       </audio>
           <p class="paras">Heeriye by Arijit Singh</p>
     </div>
      </div>
      <hr>
  
       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images/dekha.avif" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./music/dekha.mp3"  type="">
       </audio>
           <p class="paras">Dekha Tenu by Mohammad Faiz</p>
     </div>
      </div>
      <hr>
  </div>
      
      `;
  }


  
  function fun4() {
    let newpara = document.querySelector("#p4");
  
    // let para = document.querySelector("#para")
  
    // para.classList.add("hello")
  
    // let ahead = document.querySelector(".hello")
    // ahead.style.display = "block"
  
    newpara.innerHTML = `
      <div class="container hello" id="dynamo">
      <div class="row d.flex">
      <div class = "col">
      <img class="rounded  mt-3" src="./images/mahi.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/mahi.mp3"  type="">
       </audio>
           <p class="paras">O mahi O mahi by Arijit singh</p>
     </div>
      </div>
      <hr>
   <div class="row d.flex">
        <div class = "col">
        <img class="rounded  mt-3" src="./images3/kham.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song3/kah.mp3"  type="">
         </audio>
             <p class="paras">Khamoshiyan by Arijit Singh</p>
       </div>
        </div>
      
      <hr>
       <div class="row d.flex">
        <div class = "col">
        <img class="rounded" src="./images3/dard.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song3/hum.mp3"  type="">
         </audio>
             <p class="paras">Humdard by Arijit Singh</p>
       </div>
        </div>
      <hr>
   
  
       <div class="row d.flex">
      <div class = "col">
      <img class="rounded" src="./images/heeriye.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song/heeriye.mp3"  type="">
       </audio>
           <p class="paras">Heeriye by Arijit Singh</p>
     </div>
      </div>
      <hr>
  
      <div class="row d.flex">
        <div class = "col">
        <img class="rounded" src="./images3/Hamari.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song3/kah.mp3"  type="">
         </audio>
             <p class="paras">Hamari Adhuri Kahani by Arijit Singh</p>
       </div>
        </div>
      <hr>
  </div>
      
      `;
  }
  function fun6() {
    let wpara = document.querySelector("#p6");
    wpara.innerHTML = `
       <div class="container" id="damo">

      <div class="row d.flex">
      <div class = "col">
      <img class="rounded  mt-3" src="./images2/295.jpg" alt="" width=80px>
       </div>
       <div class="col me-5 mt-3">   
         <audio controls>
            <source src="./song2/295.mp3"  type="">
       </audio>
           <p class="paras">295 by Sidhu Moose wala</p>
     </div>
      </div>
      <hr>
       <div class="row d.flex">
        <div class = "col">
        <img class="rounded" src="./image4/legend.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song2/babu.mp3"  type="">
         </audio>
             <p class="paras"> Legend by Sidhu Moose wala</p>
       </div>
        </div>
        <hr>
         <div class="row d.flex">
        <div class = "col">
        <img class="rounded" src="./image4/saab.jpg" alt="" width=80px>
         </div>
         <div class="col me-5 mt-3">   
           <audio controls>
              <source src="./song2/navneet.mp3"  type="">
         </audio>
         <p class="paras">Saab by Sidhu Moose wala</p>
       </div>
        </div>
        
  
       
          
    
    
        </div>
        </div>
  
      
      `;
  //   wpara.classList.add("hello");
  //   let head = document.querySelector(".hello");
  //   head.style.display = "none";
  }
  


  
  